#include "GameManager.h"
#include "CSVOption.h"
#include "CSVTimer.h"
#include "CSVConst.h"

int GameManager::GameMode;

void GameManager::startGame() {
	// must call first to initalize timer
	CSVTimer::invalidateTime();

	// set option
	CSVOption::setOption(CSVOptionConst::ALWAYS_TRUE, 1);

	// set timer
	CSVTimer::setTime(CSVTimerConst::MAIN);
}

void GameManager::setSelectMode() {
}

void GameManager::setPlayMode() {
	GameMode = GAMEMODE::PLAY;

	// set option
	CSVOption::setOption(CSVOptionConst::ALWAYS_TRUE, 1);

	// set timer
	CSVTimer::setTime(CSVTimerConst::READY);
	CSVTimer::setTime(CSVTimerConst::PLAYSTART, 1000);
}