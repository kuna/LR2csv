class CSVBargraph {
};