#include "CSVSlider.h"

int CSVSlider::data[100];

int CSVSlider::getSliderValue(int num) {
	return data[num];
}

void CSVSlider::setSliderValue(int num, int val) {
	data[num] = val;
}