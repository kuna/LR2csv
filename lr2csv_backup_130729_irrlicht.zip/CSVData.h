#include <vector>
#include <string>
#include "CSVElement.h"
#pragma once
#include "CSVdrawarg.h"

class CSVData {
public:
	~CSVData();
	std::vector<CSVElement*> csvElement;
	std::vector<std::wstring> images;

private:
	long fileSize;

	// metadatas

	// some etcs
	std::vector<CSVElement*> csvBars;		// for selecting
	std::vector<CSVElement*> csvButtons;	// button (onmouse?)
	//std::vector<CSVElement*> csv;			// ?

	int barCenter;					// basic is 0
	CSVElement *csvBarSRC[10];		// select - bar SRC
	CSVDST *csvBarDSTOff[100];		// select - bar DST
	CSVDST *csvBarDSTOn[100];		// select - bar DST

public:
	void setFilesize(long val);
	long getFilesize();

	void addcsvBarSRC(CSVElement *ele);
	void addcsvDSTOff(CSVDST *dst);
	void addcsvDSTOn(CSVDST *dst);

	// index, src, dst, argb, rotation, filter, blending
	void drawAll(bool (*drawFunc)(int, CSVSRC*, CSVDST*));

	// TODO ...?
	//std::vector<CSVElement*> getElementsByTag(TCHAR *tag);
};