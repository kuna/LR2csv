#include "CSVOption.h"

// should redeclare (+ initalize)
int CSVOption::option[1000] = {1, 0, };

int CSVOption::getOption(int num) {
	return option[num];
}

void CSVOption::setOption(int num, int val) {
	option[num] = val;
}