/*
 * Uses irrlicht library
 * to rendering csv skin
 */

#include <irrlicht.h>
#include "CSVData.h"
#include "CSVReader.h"
#include "CSVTimer.h"
#include "CSVConst.h"
#include "GameManager.h"

using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

// instead using WinMain...
#ifdef _IRR_WINDOWS_
#pragma comment(lib, "Irrlicht.lib")
#pragma comment(linker, "/subsystem:windows /ENTRY:mainCRTStartup")
#endif

IrrlichtDevice *device;
IVideoDriver* driver;

// skin
video::ITexture* images[256];
TCHAR currentDir[256];
CSVData csvData;

// TODO: enum filter, blending.
// TODO: support blending http://irrlicht.sourceforge.net/forum/viewtopic.php?f=7&t=49075
bool drawFunc(int imgnum, CSVSRC *src, CSVDST *dst) {
	if (!images[imgnum])
		return false;

	// filter
	if (dst->getFilter()) {
		driver->getMaterial2D().TextureLayer[0].BilinearFilter=true;
	} else {
		driver->getMaterial2D().TextureLayer[0].BilinearFilter=false;
	}
	
	// TODO tmp?
	driver->draw2DImage(images[imgnum],
		core::rect<s32>(dst->getX(), dst->getY(), dst->getX2(), dst->getY2()),
		core::rect<s32>(src->x, src->y, src->wid+src->x, src->hei+src->y),
		0, &video::SColor(dst->getA(), dst->getR(), dst->getG(), dst->getB()), true);
}

int main(int argc, char **argv) {
	// init vars
	wcscpy(currentDir, L"C:\\Users\\kuna\\Documents\\Visual Studio 2010\\Projects\\lr2csv\\Debug\\");

	// init irrlichtDevice
	device =
	createDevice( video::EDT_SOFTWARE, dimension2d<u32>(640, 480), 32,
		false, false, false, 0);

	if (!device)
		return 1;

	device->setWindowCaption(L"LR2csv Alpha 140728");
	driver = device->getVideoDriver();
	ISceneManager* smgr = device->getSceneManager();
	IGUIEnvironment* guienv = device->getGUIEnvironment();

	// TODO: load csv, image & print image & character to background.
	TCHAR csvPath[256];
	wcscpy(csvPath, currentDir);
	wcscat(csvPath, L"LR2Files\\Theme\\REMI-S\\Play\\7key_Left.csv");
	CSVReader::readCSVFile(csvPath, &csvData);
	for (int i=0; i<csvData.images.size(); i++) {
		// TODO: *.* name should be preprocessed
		std::wstring ws = csvData.images[i];
		ws = currentDir + ws;

		images[i] = driver->getTexture(std::string(ws.begin(), ws.end()).c_str());
	}


	// add some controls
	gui::IGUIFont* font = device->getGUIEnvironment()->getBuiltInFont();
	guienv->addStaticText(L"Hello World! This is the Irrlicht Software renderer!",
		rect<s32>(10,10,260,22), true);

	// game just begun!
	GameManager::startGame();

	// select scene you want
	GameManager::setPlayMode();

	while(device->run())
	{
		// update time per each frame
		CSVTimer::invalidateTime();

		/*
		Anything can be drawn between a beginScene() and an endScene()
		call. The beginScene() call clears the screen with a color and
		the depth buffer, if desired. Then we let the Scene Manager and
		the GUI Environment draw their content. With the endScene()
		call everything is presented on the screen.
		*/
		driver->beginScene(true, true, SColor(255, 0, 0, 0));

		// http://irrlicht.sourceforge.net/docu/example006.html
		// test
		csvData.drawAll(drawFunc);

		TCHAR msg[30];
		swprintf(msg, 30, L"FPS %d / MAIN %d", driver->getFPS(), CSVTimer::getTime(CSVTimerConst::PLAYSTART));
		font->draw(msg,
                    core::rect<s32>(10,30,300,50),
                    video::SColor(255,255,255,255));


		// draw controls
		guienv->drawAll();

		driver->endScene();
	}

	device->drop();

	return 0;
}