#include "CSVData.h"

CSVData::~CSVData() {
	// free up all elements
	std::vector<CSVElement*>::iterator i;
	for (i = csvElement.begin(); i != csvElement.end(); i++) {
		free(*i);
		//csvElement.erase(i);
	}
	csvElement.clear();
}

void CSVData::setFilesize(long val) {
	this->fileSize = val;
}

long CSVData::getFilesize() {
	return this->fileSize;
}

void CSVData::addcsvBarSRC(CSVElement *ele) {
	int i = 0;
	while (!csvBarSRC[i]) {
		i++;
	}
	csvBarSRC[i] = ele;
}

void CSVData::addcsvDSTOff(CSVDST *dst) {
	int i = 0;
	while (!csvBarDSTOff[i]) {
		i++;
	}
	csvBarDSTOff[i] = dst;
}

void CSVData::addcsvDSTOn(CSVDST *dst) {
	int i = 0;
	while (!csvBarDSTOn[i]) {
		i++;
	}
	csvBarDSTOn[i] = dst;
}

void CSVData::drawAll(bool (*drawFunc)(int, CSVSRC*, CSVDST*)) {
	for (int i=0; i<csvElement.size(); i++) {
		csvElement[i]->drawElement(drawFunc);
	}
}