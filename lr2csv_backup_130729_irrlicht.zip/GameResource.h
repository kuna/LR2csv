class GameResource {
};