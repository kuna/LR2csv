﻿#include "CSVReader.h"
#ifndef ICONV
#include <Windows.h>	// for MultibyteToWideChar
#endif

// statics
int CSVReader::CSVTYPE_IMAGE;
int CSVReader::CSVTYPE_BUTTON;
int CSVReader::CSVTYPE_ONMOUSE;
int CSVReader::CSVTYPE_TEXT;
int CSVReader::CSVTYPE_BARGRAPH;
int CSVReader::CSVTYPE_GROOVEGUAGE;
int CSVReader::CSVTYPE_BGA;
int CSVReader::CSVTYPE_JUDGELINE;
int CSVReader::CSVTYPE_SLIDER;
int CSVReader::CSVTYPE_LINE;
int CSVReader::CSVTYPE_NOTE;
int CSVReader::CSVTYPE_LNSTART;
int CSVReader::CSVTYPE_LNEND;
int CSVReader::CSVTYPE_MINE;
int CSVReader::CSVTYPE_NUMBER;
int CSVReader::CSVTYPE_NOWJUDGE_1P;
int CSVReader::CSVTYPE_NOWCOMBO_1P;
int CSVReader::CSVTYPE_NOWJUDGE_2P;
int CSVReader::CSVTYPE_NOWCOMBO_2P;
	
int CSVReader::CSVTYPE_BAR_BODY;		// SRC
int CSVReader::CSVTYPE_BAR_BODY_OFF;	// DST
int CSVReader::CSVTYPE_BAR_BODY_ON;		// DST
int CSVReader::CSVTYPE_BAR_CENTER;
int CSVReader::CSVTYPE_BAR_AVAILABLE;
int CSVReader::CSVTYPE_BAR_FLASH;
int CSVReader::CSVTYPE_BAR_LEVEL;
int CSVReader::CSVTYPE_BAR_LAMP;
int CSVReader::CSVTYPE_BAR_MY_LAMP;
int CSVReader::CSVTYPE_BAR_RIVAL_LAMP;
int CSVReader::CSVTYPE_BAR_TITLE;
int CSVReader::CSVTYPE_BAR_RANK;
int CSVReader::CSVTYPE_BAR_RIVAL;

CSVElement *CSVReader::prevBtn;	// for BUTTON~ONMOUSE event
CSVData *CSVReader::currentCSV;
int CSVReader::condition[256];		// used #IF~#ELSEIF~#ELSE~#ENDIF. true: 1, falsed: 0, used: 2
int CSVReader::conditionDepth;
TCHAR CSVReader::dir[256];

bool CSVReader::readCSVFile(TCHAR *path, CSVData *csvData) {
	// TODO: read all element and fill data
	FILE *fp;
	fp = _wfopen(path, L"rb");
	if (!fp) return false;

	// extract dir
	wcscpy(dir, path);
	for (int i=wcslen(dir)-1; i>=0 && dir[i]!=L'\\'; i--) {
		dir[i] = 0;
	}

	fseek(fp, 0, SEEK_END);
	csvData->setFilesize(ftell(fp));
	fseek(fp, 0, SEEK_SET);

	// for unicode reading
	TCHAR *fileData;	// NULL first
	bool isUnicode;
	char sig[10];
	long fSize = csvData->getFilesize();
	fread(sig, 1, 2, fp);

	if (memcmp(sig, new char[0xFF, 0xFE], 2) == 0) {
		isUnicode = true;
	} else {
		fseek(fp, 0, SEEK_SET);
		isUnicode = false;
	}

	if (isUnicode) {
		fileData = (TCHAR*)malloc(fSize + 10);
		fread(fileData, 1, fSize, fp);
	} else {
		// ASCII - check encoding ...
		char *_noteData = (char*)malloc(fSize + 10);
		fread(_noteData, 1, fSize, fp);

		/*************************
		Automatic Encoding
		1. First, JP Encoding - check あえいおう。。。アエイオウ。。。 from tag
		2. if No JP found? then KR Encoding
		*************************/
		//BMSUtil::convert("test", "SHIFT_JIS", &noteData);
		//free(noteData);

		int converted = 0;
		if (!convert(_noteData, fSize, "SHIFT_JIS", &fileData)) {
			if (!convert(_noteData, fSize, "CP949", &fileData)) {
				// failed to convert data!
				free(_noteData);
				return false;
			}
		}

		// header len ... or first parse necessary
		// check SHIFT_JIS
		for (int i=0;i<1000;i++) {
			if (fileData[i] >= 44032 && fileData[i] <= 55203) {
				convert(_noteData, fSize, "CP949", &fileData);
				break;
			}
		}

		free(_noteData);
	}
	fclose(fp);

	initalizeConst();
	if (!parseCSVData(fileData, csvData)) {
		free(fileData);
		return false;
	}

	free(fileData);
	return true;
}

void CSVReader::initalizeConst() {
	// 명칭만 저장한다.
	CSVTYPE_IMAGE = CSVElement::getTypeInt(L"IMAGE");
	CSVTYPE_BUTTON = CSVElement::getTypeInt(L"BUTTON");
	CSVTYPE_ONMOUSE = CSVElement::getTypeInt(L"ONMOUSE");
	CSVTYPE_TEXT = CSVElement::getTypeInt(L"TEXT");
	CSVTYPE_BARGRAPH = CSVElement::getTypeInt(L"BARGRAPH");
	CSVTYPE_GROOVEGUAGE = CSVElement::getTypeInt(L"GROOVEGUAGE");
	CSVTYPE_BGA = CSVElement::getTypeInt(L"BGA");
	CSVTYPE_JUDGELINE = CSVElement::getTypeInt(L"JUDGELINE");
	CSVTYPE_SLIDER = CSVElement::getTypeInt(L"SLIDER");
	CSVTYPE_LINE = CSVElement::getTypeInt(L"LINE");
	CSVTYPE_NOTE = CSVElement::getTypeInt(L"NOTE");
	CSVTYPE_LNSTART = CSVElement::getTypeInt(L"LNSTART");
	CSVTYPE_LNEND = CSVElement::getTypeInt(L"LNEND");
	CSVTYPE_MINE = CSVElement::getTypeInt(L"MINE");
	CSVTYPE_NUMBER = CSVElement::getTypeInt(L"NUMBER");
	CSVTYPE_NOWJUDGE_1P = CSVElement::getTypeInt(L"NOWJUDGE_1P");
	CSVTYPE_NOWCOMBO_1P = CSVElement::getTypeInt(L"NOWCOMBO_1P");
	CSVTYPE_NOWJUDGE_2P = CSVElement::getTypeInt(L"NOWJUDGE_2P");
	CSVTYPE_NOWCOMBO_2P = CSVElement::getTypeInt(L"NOWCOMBO_2P");
	
	CSVTYPE_BAR_BODY = CSVElement::getTypeInt(L"BAR_BODY");
	CSVTYPE_BAR_BODY_OFF = CSVElement::getTypeInt(L"BAR_BODY_OFF");
	CSVTYPE_BAR_BODY_ON = CSVElement::getTypeInt(L"BAR_BODY_ON");
	CSVTYPE_BAR_CENTER = CSVElement::getTypeInt(L"BAR_CENTER");
	CSVTYPE_BAR_AVAILABLE = CSVElement::getTypeInt(L"BAR_AVAILABLE");
	CSVTYPE_BAR_FLASH = CSVElement::getTypeInt(L"BAR_FLASH");
	CSVTYPE_BAR_LEVEL = CSVElement::getTypeInt(L"BAR_LEVEL");
	CSVTYPE_BAR_LAMP = CSVElement::getTypeInt(L"BAR_LAMP");
	CSVTYPE_BAR_MY_LAMP = CSVElement::getTypeInt(L"BAR_MY_LAMP");
	CSVTYPE_BAR_RIVAL_LAMP = CSVElement::getTypeInt(L"BAR_RIVAL_LAMP");
	CSVTYPE_BAR_TITLE = CSVElement::getTypeInt(L"BAR_TITLE");
	CSVTYPE_BAR_RANK = CSVElement::getTypeInt(L"BAR_RANK");
	CSVTYPE_BAR_RIVAL = CSVElement::getTypeInt(L"BAR_RIVAL");
}

bool CSVReader::parseCSVData(TCHAR *data, CSVData *csvData) {
	// initalize
	currentCSV = csvData;
	conditionDepth = 0;
	
	// line parse
	TCHAR *n = NULL;
	std::vector<TCHAR*> lines;

	n = wcstok(data, L"\n");
	while (n != NULL)
	{
		if (n[wcslen(n)-1] == L'\r')
			n[wcslen(n)-1] = 0;
		
		lines.push_back(n);

		n = wcstok(NULL, L"\n");
	}

	for (int i=0; i<lines.size(); i++) {	
		processCSVLine(lines[i]);
	}

	return true;
}

void CSVReader::processCSVLine(TCHAR *data) {
	if (memcmp(data, L"//", 2*sizeof(TCHAR)) == 0) return;	// comment: do nothing
	if (data[0] != L'#') return; // wrong format: do nothing

	// parse All argument
	// max argument: 20
	int idx = 0;
	TCHAR *args[20];
	memset(args, 0, sizeof(args));
	
	TCHAR *n;
	n = wcstok(data, L",");
	while (n != NULL && idx < 20) {
		args[idx] = n;
		idx++;

		n = wcstok(NULL, L",");
	}

	// check argument
	if (wcscmp(args[0], L"#IF")==0) {
		// check condition first
		condition[conditionDepth++] = checkCondition(_wtoi(args[1]));
	} else if (wcscmp(args[0], L"#ELSE") == 0) {
		if (conditionDepth > 0) {
			if (condition[conditionDepth-1] == 0) {
				condition[conditionDepth-1] = 1;
			} else {
				condition[conditionDepth-1] = 2;
			}
		} else {
			// error: no condition found
		}
	} else if (wcscmp(args[0], L"#ELSEIF") == 0) {
		if (conditionDepth > 0) {
			if (condition[conditionDepth-1] == 0) {
				int c = checkCondition(_wtoi(args[1]));
				condition[conditionDepth-1] = c;
			} else {
				condition[conditionDepth-1] = 2;
			}
		} else {
			// error: no condition found
		}
	} else if (wcscmp(args[0], L"#ENDIF") == 0) {
		if (conditionDepth <= 0) {
			// error: no condition found
		} else {
			conditionDepth --;
		}
	}

	// check argument (when condition true)
	if ((conditionDepth > 0 && condition[conditionDepth-1] == 1) ||
		conditionDepth == 0) {
		if (wcsncmp(args[0], L"#SRC_", 5) == 0) {
			int mode = CSVElement::getTypeInt(args[0]+5);

			CSVElement *csvElement = new CSVElement();
			memset(csvElement, 0, sizeof(CSVElement));
			csvElement->setSRC(args);
			currentCSV->csvElement.push_back(csvElement);

			// BAR_BODY
			if (mode == CSVTYPE_BAR_BODY) {
				currentCSV->addcsvBarSRC(csvElement);
			}

			// if ONMOUSE, then relate to previous Button
			if (mode == CSVTYPE_ONMOUSE && !prevBtn) {
				prevBtn->setRelatedElement(csvElement);
			}

			// if button, then store to previous one
			if (mode == CSVTYPE_BUTTON) {
				prevBtn = csvElement;
			}
		} else if (wcsncmp(args[0], L"#DST_", 5) == 0) {
			int mode = CSVElement::getTypeInt(args[0]+5);

			// if BAR_BODY_OFF / BAR_BODY_ON
			if (mode == CSVTYPE_BAR_BODY_OFF) {
				CSVDST *dst = new CSVDST();
				dst->setDST(args);
				currentCSV->addcsvDSTOff(dst);
			} else if (mode == CSVTYPE_BAR_BODY_ON) {
				CSVDST *dst = new CSVDST();
				dst->setDST(args);
				currentCSV->addcsvDSTOn(dst);
			} else {
				// add to previous SRC
				if (currentCSV->csvElement.size() <= 0) {
					// error: need SRC before DST !
				} else {
					CSVElement *e = currentCSV->csvElement[currentCSV->csvElement.size() - 1];
					e->addDST(args);
				}
			}
		} else if (wcscmp(args[0], L"#IMAGE") == 0) {
			for (int i=0; i<wcslen(args[1]); i++)
				if (args[1][i] == L'¥')
					args[1][i] = L'\\';
			TCHAR *n = new TCHAR[256];
			wcscpy(n, args[1]);
			//wcscpy(n, dir); - including dir
			//wcscat(n, args[1]);
			currentCSV->images.push_back(n);
		} else if (wcscmp(args[0], L"#FONT") == 0) {
		} else if (wcscmp(args[0], L"#LR2FONT") == 0) {
		} else if (wcscmp(args[0], L"#ENDOFHEADER") == 0) {
		} else if (wcscmp(args[0], L"#SCRATCHSIDE") == 0) {
		} else if (wcscmp(args[0], L"#TRANSCOLOR") == 0) {
		} else if (wcscmp(args[0], L"#STARTINPUT") == 0) {
		} else if (wcscmp(args[0], L"#LOADSTART") == 0) {
		} else if (wcscmp(args[0], L"#LOADEND") == 0) {
		} else if (wcscmp(args[0], L"#PLAYSTART") == 0) {
		} else if (wcscmp(args[0], L"#FADEOUT") == 0) {
		} else if (wcscmp(args[0], L"#CLOSE") == 0) {
		}
	}
}

int CSVReader::checkCondition(int num) {
	// call DstOption for validation
	// TODO: CSVOption work.

	return 1;
}

bool CSVReader::convert(const char *input, int len, const char *from, TCHAR **output) {
	// convert encoding to TCHAR
#ifdef ICONV
    iconv_t cd;
    if ((cd = iconv_open("UTF-16LE", from)) == (iconv_t) -1) {
        iconv_close(cd);
        return FALSE;
    } else {
        size_t in_bytes = len;
		size_t out_bytes = (in_bytes+1) *4;
        char *out = (char *) calloc(out_bytes, sizeof(char));
        char *outp = out;

		if(iconv(cd, &input, &in_bytes, &outp, &out_bytes)==-1) {
			char *sterr = strerror(errno);
			iconv_close(cd);
			if (out) free(out);
			return FALSE;
		}

		*output = (TCHAR*)malloc(out_bytes);
		wcscpy(*output, (TCHAR*)out);

        iconv_close(cd);
		if (out) free(out);
        return TRUE;
	}
#else
	// code page 50222?
	int codepage = CP_ACP;
	if (strcmp(from, "SHIFT_JIS") == 0)
		codepage = 50220;
	int nLen = MultiByteToWideChar(codepage, 0, input, strlen(input), NULL, NULL);
	*output = new TCHAR[nLen];
	MultiByteToWideChar(codepage, 0, input, strlen(input), *output, nLen);
#endif
	return true;
}