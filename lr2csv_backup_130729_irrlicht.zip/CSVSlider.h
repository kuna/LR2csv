// muki: direction (0 - clock)
// range
// type: number
// disable

class CSVSlider {
private:
	static int data[100];
public:
	static int getSliderValue(int num);
	static void setSliderValue(int num, int val);
};