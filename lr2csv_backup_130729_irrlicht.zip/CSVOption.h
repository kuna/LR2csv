class CSVOption {
public:
	CSVOption();
	static int getOption(int num);
	static void setOption(int num, int val);

private:
	static int option[1000];
};