#include <vector>
#include <tchar.h>
#pragma once

class CSVDST {
public:
	int dst[20];

public:
	int getTime();
	int getX();
	int getY();
	int getX2();
	int getY2();
	int getWidth();
	int getHeight();
	int getAcc();
	int getA();
	int getR();
	int getG();
	int getB();
	int getBlend();
	int getFilter();
	int getAngle();
	int getCenter();
	int getLoop();
	int getTimer();
	int getOP1();
	int getOP2();
	int getOP3();
	bool checkOP();

	void setDST(TCHAR *args[]);
};

class CSVSRC {
public:
	int x,y,wid,hei;
};

class CSVElement {
public:
	~CSVElement();
	int type;
	int src[20];
	std::vector<CSVDST*> dst;

public:
	void setSRC(TCHAR *data[]);
	void addDST(TCHAR *data[]);
	int getImgNum();
	int getType();
	int getX();
	int getY();
	int getWidth();
	int getHeight();
	int getdivX();
	int getdivY();
	int getCycle();
	int getTimer();
	int getOP1();
	int getOP2();
	int getOP3();
	bool checkOP();

	// calculation part
	bool getSRC(CSVSRC *c);
	bool getDST(CSVDST *c);

	void setType(int type);
	static int getTypeInt(TCHAR *str);

	// relation
	bool isRelatedExists();
	void setRelatedElement(CSVElement *csv);

	// index, src, dst, argb, rotation, filter, blending
	void drawElement(bool (*drawFunc)(int, CSVSRC*, CSVDST*));

private:
	CSVElement* related;	// this will be used with button (ONMOUSE)
};