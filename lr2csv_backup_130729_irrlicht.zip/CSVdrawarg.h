#pragma once

class CSVRECT {
public:
	int x1, y1, x2, y2;
};

class CSVARGB {
public:
	int a, r, g, b;
};