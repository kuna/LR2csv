class CSVNumber {
public:
	static int getNumber(int num);
	static void setNumber(int num, int val);
private:
	static int data[1000];
};